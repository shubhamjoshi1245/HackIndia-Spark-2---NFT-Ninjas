document.getElementById('loginForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    
    console.log('Email:', email);
    console.log('Password:', password);

    // Add your login logic here

    // Simulate form submission for demonstration purposes
    this.submit();
});
